<?php
require "../config.php";require_role("admin");$msg="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $y=(int)$_POST["year_no"];$s=(int)$_POST["semester"];$n=trim($_POST["name"]);$video=trim($_POST["video_url"]??"");
 $st=$conn->prepare("INSERT INTO subjects(year_no,semester,name,video_url) VALUES(?,?,?,?)");
 $st->bind_param("iiss",$y,$s,$n,$video);$st->execute();
 $sid=$st->insert_id;
 $levels=[["Basic","Fundamental concepts, notes and beginner exercises."],["Intermediate","Intermediate concepts, examples and practical exercises."],["Advanced","Advanced concepts, problem solving and applications."]];
 foreach($levels as $lv){$x=$conn->prepare("INSERT INTO levels(subject_id,level_name,description) VALUES(?,?,?)");$x->bind_param("iss",$sid,$lv[0],$lv[1]);$x->execute();}
 $msg="Subject added successfully.";
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Subjects</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="wrap"><div class="card"><a href="dashboard.php">← Admin</a><h2>Add Subject</h2><?php if($msg):?><div class="alert ok"><?=h($msg)?></div><?php endif;?><form method="post"><select name="year_no"><option value="1">1st Year</option><option value="2">2nd Year</option><option value="3">3rd Year</option></select><select name="semester"><?php for($i=1;$i<=6;$i++):?><option><?=$i?></option><?php endfor;?></select><input name="name" placeholder="Subject name" required><input name="video_url" type="url" placeholder="Course video URL (YouTube watch / youtu.be)" ><button class="btn">Add Subject</button></form><p class="muted">Paste one approved YouTube course-video URL for each course. It will appear as an embedded video on the student course page.</p><h3>Existing Subjects</h3><ul><?php $rs=$conn->query("SELECT * FROM subjects ORDER BY year_no,semester,id");while($r=$rs->fetch_assoc()):?><li>Year <?=$r["year_no"]?> / Sem <?=$r["semester"]?> — <?=h($r["name"])?><br><small><?=!empty($r["video_url"])?"🎥 Video attached":"⚠ No video attached yet"?></small></li><?php endwhile;?></ul></div></div></body></html>
