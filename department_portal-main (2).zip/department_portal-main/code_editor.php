<?php require "../config.php"; require_role("student"); $course=trim($_GET["course"]??"Practice"); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Code Editor | LearnSphere</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body><div class="learn-wrap"><div class="learn-top"><a href="javascript:history.back()">← Back</a><a href="dashboard.php">Dashboard</a></div>
<div class="panel"><p class="eyebrow">PRACTICE ZONE</p><h1>💻 Browser Code Editor</h1><p class="muted">Write HTML, CSS and JavaScript, then click Run. Your code is saved in this browser for this course.</p>
<div class="editor-toolbar"><b><?=h($course)?></b><button class="btn" type="button" onclick="runCode()">▶ Run</button><button class="btn secondary" type="button" onclick="resetCode()">Reset</button></div>
<div class="editor-grid"><div><label>HTML</label><textarea id="htmlCode" spellcheck="false"><h1>Hello LearnSphere</h1>
<p>Edit this code and click Run.</p>
<button onclick="showMessage()">Click Me</button></textarea></div><div><label>CSS</label><textarea id="cssCode" spellcheck="false">body{font-family:Arial;padding:30px} h1{color:#5d3fd0} button{padding:10px 15px}</textarea></div><div><label>JavaScript</label><textarea id="jsCode" spellcheck="false">function showMessage(){ alert("JavaScript is working!"); }</textarea></div></div>
<h3>Output</h3><iframe id="outputFrame" class="code-output" sandbox="allow-scripts"></iframe></div></div>
<script>
const key='learnsphere_editor_'+<?=json_encode($course)?>;
function runCode(){const h=document.getElementById('htmlCode').value,c=document.getElementById('cssCode').value,j=document.getElementById('jsCode').value;
localStorage.setItem(key,JSON.stringify({h,c,j}));
const doc='<!doctype html><html><head><style>'+c.replace(/<\/style/gi,'<\\\\/style')+'</style></head><body>'+h+'<script>'+j.replace(/<\/script/gi,'<\\\\/script')+'<\/script></body></html>';
document.getElementById('outputFrame').srcdoc=doc;}
function resetCode(){localStorage.removeItem(key);location.reload();}
(function(){try{const x=JSON.parse(localStorage.getItem(key)||'null');if(x){htmlCode.value=x.h;cssCode.value=x.c;jsCode.value=x.j}}catch(e){}runCode()})();
</script></body></html>
