/* LearnSphere first-login voice welcome
   - Plays automatically only once per logged-in user/browser.
   - Replay works whenever the user presses Replay.
   - Mute preference is remembered.
   - Gracefully does nothing if Speech Synthesis is unavailable.
*/
(function () {
  "use strict";

  function initWelcomeVoice() {
    var box = document.getElementById("welcomeVoice");
    if (!box) return;

    var role = box.getAttribute("data-role") || "";
    var userId = box.getAttribute("data-user-id") || "";
    var name = box.getAttribute("data-name") || "";
    var pending = box.getAttribute("data-pending") === "1";
    var supported = "speechSynthesis" in window && "SpeechSynthesisUtterance" in window;

    var roleText = role === "student"
      ? "Welcome to LearnSphere, " + name + ". Happy learning!"
      : role === "staff"
        ? "Welcome to LearnSphere, " + name + ". Have a productive day!"
        : "Welcome to LearnSphere, Administrator.";

    var seenKey = "learnsphere_welcome_seen_" + role + "_" + userId;
    var muteKey = "learnsphere_voice_muted";
    var speaker = document.getElementById("welcomeSpeaker");
    var mute = document.getElementById("welcomeMute");
    var replay = document.getElementById("welcomeReplay");
    var status = document.getElementById("welcomeVoiceStatus");

    function setStatus(text) {
      if (status) status.textContent = text;
    }

    function isMuted() {
      return localStorage.getItem(muteKey) === "1";
    }

    function updateButtons() {
      if (!speaker || !mute) return;
      var muted = isMuted();
      speaker.setAttribute("aria-pressed", muted ? "false" : "true");
      mute.setAttribute("aria-pressed", muted ? "true" : "false");
      speaker.classList.toggle("active", !muted);
      mute.classList.toggle("active", muted);
    }

    function stop() {
      if (supported) window.speechSynthesis.cancel();
    }

    function speak(force) {
      if (!supported) {
        setStatus("Voice is not supported in this browser.");
        return;
      }
      if (!force && isMuted()) {
        setStatus("Voice muted.");
        return;
      }

      stop();
      var utterance = new SpeechSynthesisUtterance(roleText);
      utterance.lang = "en-IN";
      utterance.rate = 0.92;
      utterance.pitch = 1;
      utterance.volume = 1;

      utterance.onstart = function () { setStatus("Playing welcome message…"); };
      utterance.onend = function () { setStatus("Welcome message finished."); };
      utterance.onerror = function () { setStatus("Voice could not be played. You can continue normally."); };

      window.speechSynthesis.speak(utterance);
    }

    if (speaker) {
      speaker.addEventListener("click", function () {
        localStorage.setItem(muteKey, "0");
        updateButtons();
        speak(true);
      });
    }

    if (mute) {
      mute.addEventListener("click", function () {
        stop();
        localStorage.setItem(muteKey, "1");
        updateButtons();
        setStatus("Voice muted.");
      });
    }

    if (replay) {
      replay.addEventListener("click", function () {
        speak(false);
      });
    }

    updateButtons();

    if (!supported) {
      if (speaker) speaker.disabled = true;
      if (replay) replay.disabled = true;
      setStatus("Speech synthesis is not supported. The website will continue normally.");
      return;
    }

    /* First successful login: play once, then remember it for this user/browser. */
    if (pending && !localStorage.getItem(seenKey)) {
      localStorage.setItem(seenKey, "1");
      setTimeout(function () { speak(false); }, 450);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initWelcomeVoice);
  } else {
    initWelcomeVoice();
  }
})();
