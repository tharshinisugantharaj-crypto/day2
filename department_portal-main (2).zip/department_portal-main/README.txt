DEPARTMENT LEARNING & EXAMINATION PORTAL
==========================================
Requirements:
- XAMPP (Apache + MySQL)
- PHP 8+ recommended
- A browser

INSTALL:
1. Copy the folder "department_portal" into C:\xampp\htdocs\
2. Start Apache and MySQL in XAMPP.
3. Open http://localhost/phpmyadmin
4. Create/import the database using database.sql.
5. Open http://localhost/department_portal/

DEMO ACCOUNTS:
Admin: admin@department.local / admin123
Staff: staff@department.local / staff123

Student:
Use Student Registration to create an account.

FEATURES:
- Student registration/login
- 1st/2nd/3rd year and semesters
- Subjects
- Basic/Intermediate/Advanced levels
- PDF/reference material upload
- 50-mark mock tests (25 pass mark)
- Course completion tracking
- Printable course certificate
- Main exam scheduling
- Registration opens during the 14 days before exam date
- Staff monitoring
- Admin dashboard

IMPORTANT:
This is a working starter project for your department project. For production use, add CSRF protection, stronger role permissions, email SMTP/API integration, audit logs, secure file validation, and a real main-exam question/result module.
