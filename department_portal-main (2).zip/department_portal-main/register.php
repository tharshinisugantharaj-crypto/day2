<?php require "config.php"; $msg="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $name=trim($_POST["name"]);$reg=trim($_POST["reg_no"]);$email=trim($_POST["email"]);$pass=$_POST["password"];$year=(int)$_POST["year_no"];
 $hash=password_hash($pass,PASSWORD_DEFAULT);
 $st=$conn->prepare("INSERT INTO users(name,reg_no,email,password,role,year_no) VALUES(?,?,?,?, 'student',?)");
 $st->bind_param("ssssi",$name,$reg,$email,$hash,$year);
 if($st->execute()){header("Location: login.php?registered=1");exit;} $msg="Registration failed. Email/Register number may already exist.";
} ?>
<!doctype html><html><head><meta charset="utf-8"><title>Register</title><link rel="stylesheet" href="assets/css/style.css"></head><body>
<div class="wrap"><div class="card"><h2>Student Registration</h2><?php if($msg):?><div class="alert"><?=$msg?></div><?php endif;?>
<form method="post" onsubmit="return validateRegister()"><input name="name" placeholder="Student name" required><input name="reg_no" placeholder="Register number" required><input type="email" name="email" placeholder="Email" required><input type="password" id="password" name="password" placeholder="Password" required minlength="6">
<select name="year_no" required><option value="">Select year</option><option value="1">1st Year</option><option value="2">2nd Year</option><option value="3">3rd Year</option></select><button class="btn">Register</button></form><p>Already registered? <a href="login.php">Login</a></p></div></div><script src="assets/js/app.js"></script></body></html>