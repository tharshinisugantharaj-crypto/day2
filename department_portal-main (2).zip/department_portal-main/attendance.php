<?php
require "../config.php";require_role("staff");
$rs=$conn->query("SELECT a.id,a.login_at,a.logout_at,u.name,u.reg_no,u.email
                  FROM attendance_sessions a JOIN users u ON u.id=a.student_id
                  WHERE u.role='student' ORDER BY a.login_at DESC");
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Student Login & Logout</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="wrap"><div class="top"><h1>Student Login & Logout</h1><a class="btn secondary" href="dashboard.php">← Staff Dashboard</a></div><div class="panel"><p class="muted">Every student login creates a record. Logout time is filled when the student uses the portal Logout button. An active session shows “Still logged in”.</p><div style="overflow:auto"><table class="table"><tr><th>Student</th><th>Register No</th><th>Email</th><th>Login Time</th><th>Logout Time</th><th>Status</th></tr><?php while($r=$rs->fetch_assoc()):?><tr><td><?=h($r["name"])?></td><td><?=h($r["reg_no"])?></td><td><?=h($r["email"])?></td><td><?=h($r["login_at"])?></td><td><?=h($r["logout_at"]??"—")?></td><td><?=$r["logout_at"]?"Logged out":"🟢 Still logged in"?></td></tr><?php endwhile;?></table></div></div></div></body></html>
