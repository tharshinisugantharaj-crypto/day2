<?php
session_start();
$host="localhost"; $user="root"; $pass=""; $db="department_portal";
$conn=new mysqli($host,$user,$pass,$db);
if($conn->connect_error) die("Database connection failed: ".$conn->connect_error);
$conn->set_charset("utf8mb4");
function h($v){return htmlspecialchars($v??"",ENT_QUOTES,"UTF-8");}
function require_login(){ if(empty($_SESSION["user_id"])) { header("Location: login.php"); exit; } }
function require_role($role){ require_login(); if(($_SESSION["role"]??"")!==$role){header("Location: login.php");exit;} }
?>