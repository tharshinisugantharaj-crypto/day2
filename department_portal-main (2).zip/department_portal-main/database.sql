CREATE DATABASE IF NOT EXISTS department_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE department_portal;
CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, reg_no VARCHAR(50) UNIQUE,
 email VARCHAR(150) UNIQUE NOT NULL, password VARCHAR(255) NOT NULL,
 role ENUM('student','staff','admin') DEFAULT 'student', year_no TINYINT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE subjects(id INT AUTO_INCREMENT PRIMARY KEY, year_no TINYINT NOT NULL, semester TINYINT NOT NULL, name VARCHAR(150) NOT NULL);
CREATE TABLE levels(id INT AUTO_INCREMENT PRIMARY KEY, subject_id INT NOT NULL, level_name ENUM('Basic','Intermediate','Advanced') NOT NULL, description TEXT, UNIQUE(subject_id,level_name), FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE);
CREATE TABLE materials(id INT AUTO_INCREMENT PRIMARY KEY, level_id INT NOT NULL, title VARCHAR(200) NOT NULL, file_path VARCHAR(255), FOREIGN KEY(level_id) REFERENCES levels(id) ON DELETE CASCADE);
CREATE TABLE progress(id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL, level_id INT NOT NULL, completed TINYINT DEFAULT 0, mark INT DEFAULT NULL, completed_at DATETIME NULL, UNIQUE(student_id,level_id), FOREIGN KEY(student_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(level_id) REFERENCES levels(id) ON DELETE CASCADE);
CREATE TABLE questions(id INT AUTO_INCREMENT PRIMARY KEY, level_id INT NOT NULL, question TEXT NOT NULL, a VARCHAR(255), b VARCHAR(255), c VARCHAR(255), d VARCHAR(255), answer CHAR(1) NOT NULL, FOREIGN KEY(level_id) REFERENCES levels(id) ON DELETE CASCADE);
CREATE TABLE mock_results(id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL, level_id INT NOT NULL, mark INT NOT NULL, taken_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE(student_id,level_id), FOREIGN KEY(student_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(level_id) REFERENCES levels(id) ON DELETE CASCADE);
CREATE TABLE main_exams(id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(200), exam_date DATE NOT NULL, start_time TIME, end_time TIME, total_marks INT DEFAULT 100, pass_mark INT DEFAULT 40, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE exam_registrations(id INT AUTO_INCREMENT PRIMARY KEY, exam_id INT NOT NULL, student_id INT NOT NULL, registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE(exam_id,student_id), FOREIGN KEY(exam_id) REFERENCES main_exams(id) ON DELETE CASCADE, FOREIGN KEY(student_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE notifications(id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(200), message TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);

INSERT INTO users(name,reg_no,email,password,role) VALUES
('System Admin','ADMIN001','admin@department.local',SHA2('admin123',256),'admin'),
('Department Staff','STAFF001','staff@department.local',SHA2('staff123',256),'staff');

INSERT INTO subjects(year_no,semester,name) VALUES
(1,1,'Programming in C'),(1,1,'Computer Fundamentals'),(1,1,'Mathematics'),(1,1,'Digital Electronics'),(1,1,'Communication Skills'),
(1,2,'Data Structures'),(1,2,'Object Oriented Programming'),(1,2,'Database Management Systems'),(1,2,'Web Technology'),(1,2,'Operating Systems'),
(2,3,'Java Programming'),(2,3,'Computer Networks'),(2,3,'Software Engineering'),(2,3,'Statistics'),(2,3,'Environmental Studies'),
(2,4,'PHP and MySQL'),(2,4,'Python Programming'),(2,4,'Mobile Application Development'),(2,4,'Computer Architecture'),(2,4,'Project Management'),
(3,5,'Artificial Intelligence'),(3,5,'Cyber Security'),(3,5,'Cloud Computing'),(3,5,'Data Analytics'),(3,5,'Internet of Things'),
(3,6,'Machine Learning'),(3,6,'Big Data'),(3,6,'Web Development Project'),(3,6,'Entrepreneurship'),(3,6,'Major Project');

INSERT INTO levels(subject_id,level_name,description)
SELECT id,'Basic','Fundamental concepts, notes and beginner exercises.' FROM subjects;
INSERT INTO levels(subject_id,level_name,description)
SELECT id,'Intermediate','Intermediate concepts, examples and practical exercises.' FROM subjects;
INSERT INTO levels(subject_id,level_name,description)
SELECT id,'Advanced','Advanced concepts, problem solving and applications.' FROM subjects;

INSERT INTO questions(level_id,question,a,b,c,d,answer)
SELECT l.id,'Which language is mainly used in this course?','C','HTML','SQL','CSS','A' FROM levels l WHERE l.level_name='Basic';
INSERT INTO questions(level_id,question,a,b,c,d,answer)
SELECT l.id,'Which level comes after Basic?','Advanced','Intermediate','None','Final','B' FROM levels l WHERE l.level_name='Basic';
INSERT INTO questions(level_id,question,a,b,c,d,answer)
SELECT l.id,'Which level is the final course level?','Basic','Intermediate','Advanced','None','C' FROM levels l WHERE l.level_name='Advanced';

-- LEARNSPHERE MATERIALS
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Programming in C — Basic Study Notes','uploads/materials/programming_in_c_basic.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Programming in C' AND l.level_name='Basic' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Programming in C — Intermediate Study Notes','uploads/materials/programming_in_c_intermediate.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Programming in C' AND l.level_name='Intermediate' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Programming in C — Advanced Study Notes','uploads/materials/programming_in_c_advanced.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Programming in C' AND l.level_name='Advanced' LIMIT 1;
-- Reference guide: Programming in C
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Computer Fundamentals — Basic Study Notes','uploads/materials/computer_fundamentals_basic.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Computer Fundamentals' AND l.level_name='Basic' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Computer Fundamentals — Intermediate Study Notes','uploads/materials/computer_fundamentals_intermediate.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Computer Fundamentals' AND l.level_name='Intermediate' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Computer Fundamentals — Advanced Study Notes','uploads/materials/computer_fundamentals_advanced.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Computer Fundamentals' AND l.level_name='Advanced' LIMIT 1;
-- Reference guide: Computer Fundamentals
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Mathematics — Basic Study Notes','uploads/materials/mathematics_basic.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Mathematics' AND l.level_name='Basic' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Mathematics — Intermediate Study Notes','uploads/materials/mathematics_intermediate.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Mathematics' AND l.level_name='Intermediate' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Mathematics — Advanced Study Notes','uploads/materials/mathematics_advanced.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Mathematics' AND l.level_name='Advanced' LIMIT 1;
-- Reference guide: Mathematics
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Digital Electronics — Basic Study Notes','uploads/materials/digital_electronics_basic.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Digital Electronics' AND l.level_name='Basic' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Digital Electronics — Intermediate Study Notes','uploads/materials/digital_electronics_intermediate.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Digital Electronics' AND l.level_name='Intermediate' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Digital Electronics — Advanced Study Notes','uploads/materials/digital_electronics_advanced.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Digital Electronics' AND l.level_name='Advanced' LIMIT 1;
-- Reference guide: Digital Electronics
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Communication Skills — Basic Study Notes','uploads/materials/communication_skills_basic.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Communication Skills' AND l.level_name='Basic' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Communication Skills — Intermediate Study Notes','uploads/materials/communication_skills_intermediate.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Communication Skills' AND l.level_name='Intermediate' LIMIT 1;
INSERT INTO materials(level_id,title,file_path) SELECT l.id,'Communication Skills — Advanced Study Notes','uploads/materials/communication_skills_advanced.pdf' FROM levels l JOIN subjects s ON s.id=l.subject_id WHERE s.name='Communication Skills' AND l.level_name='Advanced' LIMIT 1;
-- Reference guide: Communication Skills
