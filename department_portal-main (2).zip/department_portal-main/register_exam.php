<?php

require "../config.php";
require_role("student");

if (!isset($_GET["id"])) {
    die("Exam ID missing.");
}

$exam_id = (int)$_GET["id"];
$student_id = (int)$_SESSION["user_id"];

/* Get exam */
$stmt = $conn->prepare("SELECT * FROM main_exams WHERE id = ?");
$stmt->bind_param("i", $exam_id);
$stmt->execute();

$result = $stmt->get_result();
$exam = $result->fetch_assoc();

if (!$exam) {
    die("Exam not found.");
}

/* Check whether already registered */
$check = $conn->prepare(
    "SELECT id FROM exam_registrations 
     WHERE exam_id = ? AND student_id = ?"
);

$check->bind_param("ii", $exam_id, $student_id);
$check->execute();

$already = $check->get_result();

if ($already->num_rows > 0) {
    header("Location: exam.php?status=already");
    exit;
}

/* Register student */
$insert = $conn->prepare(
    "INSERT INTO exam_registrations (exam_id, student_id)
     VALUES (?, ?)"
);

$insert->bind_param("ii", $exam_id, $student_id);

if ($insert->execute()) {

    header("Location: exam.php?status=success");
    exit;

} else {

    die("Registration failed: " . $conn->error);
}

?>
